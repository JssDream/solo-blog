title: Intellij IDEA 高效使用教程(插件)
date: '2021-12-09 13:58:15'
updated: '2021-12-09 13:58:15'
tags: [IntellijIDEA, 插件]
permalink: /articles/2021/12/09/1639029495498.html
---
## # Intellij IDEA 高效使用教程（插件）

![image.png](https://b3logfile.com/file/2021/12/image-ca86f256.png)

安装好Intellij idea之后，进行如下的初始化操作，工作效率提升十倍。

## 一. 安装插件

**1. Codota 代码智能提示插件**

![图片](https://b3logfile.com/file/2021/12/solo-fetchupload-2069949241295073283-8d1ab5af.webp)

只要打出首字母就能联想出一整条语句，这也太智能了，还显示了每条语句使用频率。

原因是它学习了我的项目代码，总结出了我的代码偏好。

![图片](https://b3logfile.com/file/2021/12/solo-fetchupload-6341152902950643044-1336749f.webp)

**如果让它再加上机器学习，人工智能写代码的时代还会远吗？**

**2. Key Promoter X 快捷键提示插件**

![图片](data:image/gif;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVQImWNgYGBgAAAABQABh6FO1AAAAABJRU5ErkJggg==)

每次都会在右下角弹窗提示，帮助我们快速熟悉快捷键。

**3. CodeGlance 显示代码缩略图插件**

![图片](https://b3logfile.com/file/2021/12/solo-fetchupload-3986026699248871484-7a34dc46.webp)

当代码很多的时候，方便查看，很有用。

**4. Lombok 简化臃肿代码插件**

![图片](https://b3logfile.com/file/2021/12/solo-fetchupload-5406015942864567475-e5a2a4ed.webp)

实体类中的get/set/构造/toString/hashCode等方法，都不需要我们再手动写了

**5. Alibaba Java Coding Guidelines 阿里巴巴代码规范检查插件**

![图片](https://b3logfile.com/file/2021/12/solo-fetchupload-8910796448170792652-74e9cfb2.webp)

会按照阿里Java开发手册上规范帮我们检查代码，然后对代码做不同颜色展示，鼠标放上去，会看到提示内容，帮助我们写出更规范的代码。

**6. CamelCase 驼峰命名和下划线命名转换**

![图片](https://b3logfile.com/file/2021/12/solo-fetchupload-5723017167194504650-b7124b76.webp)

这几种风格的命名方式，用快捷键 ⇧ + ⌥ + U / Shift + Alt + U可以进行快速转换，当我们需要修改大量变量名称的时候很方便。

**7. MybatisX 高效操作Mybatis插件**

![图片](https://b3logfile.com/file/2021/12/solo-fetchupload-2777196467742761734-645d980f.webp)

**8. SonarLint 代码质量检查插件**

![图片](https://b3logfile.com/file/2021/12/solo-fetchupload-3631286403618567907-8d55b69c.webp)

提示我不要用System.out输出，要用logger输出，诸如此类，帮助我们提升代码质量。

**9. Save Actions 格式化代码插件**

![图片](https://b3logfile.com/file/2021/12/solo-fetchupload-2012613769439825696-aaeb8236.webp)

可以帮忙我们优化包导入，自动给没有修改的变量添加final修饰符，调用方法的时候自动添加this关键字等，使我们的代码更规范统一。

**10. CheckStyle 代码风格检查插件**

功能跟Alibaba Java Coding Guidelines类似

**11. Grep Console 自定义控制台输出格式插件**

![图片](https://b3logfile.com/file/2021/12/solo-fetchupload-2544995410612683380-c7d7d961.webp)

**12. MetricsReloaded 代码复杂度检查插件**

![图片](https://b3logfile.com/file/2021/12/solo-fetchupload-6775552316988801469-27209de0.webp)

**13. Statistic 代码统计插件**

![图片](https://b3logfile.com/file/2021/12/solo-fetchupload-8840834194363532713-18dd86df.webp)

**14. Translation 翻译插件**

![图片](https://b3logfile.com/file/2021/12/solo-fetchupload-3253005181190514667-7edac1ca.webp)

**15. Rainbow Brackets 彩虹括号插件**

![图片](https://b3logfile.com/file/2021/12/solo-fetchupload-1735221263149827559-097c8b03.webp)

成对儿的括号显示相同的颜色，有了这个插件，我的近视都好了。

## 二. 自定义创建live template，快速写代码

![图片](https://b3logfile.com/file/2021/12/solo-fetchupload-3010163089477214666-4c6ced67.webp)

只要输入**apr** ，就能自动提示，并且生成**Autowired** 语句了。可以根据自己的代码习惯，自定义一些代码模板，帮助我们快速写代码。

![图片](https://b3logfile.com/file/2021/12/solo-fetchupload-8201793919251786293-dffaaa10.webp)

## 三. 修改全局配置，提升工作效率

**1. 优化导包配置**

![图片](https://b3logfile.com/file/2021/12/solo-fetchupload-6103759833704813512-0ab02228.webp)

**2. 取消tab页单行显示**

![图片](https://b3logfile.com/file/2021/12/solo-fetchupload-3672766011502900578-721d96e9.webp)

![图片](https://b3logfile.com/file/2021/12/solo-fetchupload-3251612717484556922-983d975d.webp)

多行显示更多的文件，方便查看。

**3. 双斜杠注释改成紧跟代码头**

![图片](https://b3logfile.com/file/2021/12/solo-fetchupload-5044486094034362016-14355efa.webp)

![图片](https://b3logfile.com/file/2021/12/solo-fetchupload-2575772614443514969-afd8bab8.webp)

**4. 选中复制整行**

![图片](https://b3logfile.com/file/2021/12/solo-fetchupload-5379164632966494878-ed26fa28.webp)

![图片](https://b3logfile.com/file/2021/12/solo-fetchupload-1851181668772931879-5f0b3f96.webp)

原本只会复制你选中的代码，改完配置后，就能复制整行，无论你是否完全选中。

**5. 取消匹配大小写**

![图片](https://b3logfile.com/file/2021/12/solo-fetchupload-5845891536010864922-236dfcea.webp)

取消勾选后，输入小写 **s** ，也能提示出 **String**

**6. 优化版本控制的目录颜色展示**

![图片](https://b3logfile.com/file/2021/12/solo-fetchupload-8943989374416043786-547e7a3d.webp)

**7. 创建文件时，自动生成作者和时间信息**

![图片](https://b3logfile.com/file/2021/12/solo-fetchupload-8251407680868938477-caa89ea7.webp)

**8 . 显示行号和方法分割线**

![图片](https://b3logfile.com/file/2021/12/solo-fetchupload-3370967836657706318-ade1f726.webp)

**你还知道哪些关于Intelij idea高效操作或插件呢？**

