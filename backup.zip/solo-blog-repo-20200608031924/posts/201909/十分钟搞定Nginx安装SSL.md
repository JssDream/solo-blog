title: 十分钟搞定——Nginx安装SSL
date: '2019-09-03 20:48:06'
updated: '2019-09-03 20:51:18'
tags: [Nginx, Linux, 随记, 魔鬼命令]
permalink: /articles/2019/09/03/1567514885863.html
---
![](https://img.hacpai.com/bing/20181123.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 前言
       
 本文的Nginx主要是使用Docker安装，所以着重讲解容器版Nginx安装SSL过程，当然普通的Nginx安装也适用，都是通用的！

## 准备

1. 安装SSL首先需要有域名，关于域名注册、备案不做讲解，网上好多教程可以自行查阅，域名的注册主要有腾讯云、阿里云、其他云
2. 注册和备案好域名之后，我们就需要进行申请SSL证书，关于证书的申请过程不做详细介绍，腾讯云和阿里云都是有专门的文档介绍
	* [腾讯云SSL文档](https://cloud.tencent.com/document/product/400/8422)
	* [阿里云SSL文档](https://help.aliyun.com/document_detail/28554.html?spm=a2c4g.11186623.6.554.137d2179gZM50x)
3. 下载证书
	* 腾讯云：
	> 直接点击下载:
	![image.png](https://img.hacpai.com/file/2019/09/image-1377912f.png)
	> 目录如下：
	![image.png](https://img.hacpai.com/file/2019/09/image-3d077290.png)
	
	* 阿里云:(PS:没有使用阿里云 😰 )
	[阿里云Nginx安装文档](https://help.aliyun.com/document_detail/98728.html?spm=a2c4g.11186623.2.19.5e092242HQlWed#concept-n45-21x-yfb)

## 操作

1. 首先创建文件夹备用
```
mkdir /data/nginx/logs /data/nginx/www /data/nginx/ssl /data/nginx/conf
```
2. 将Nginx文件夹中的两个文件上传到服务器`/data/nginx/ssl`
![image.png](https://img.hacpai.com/file/2019/09/image-faea655d.png)

3. 将Nginx容器中的配置文件cp出来
```
docker cp nginx:/etc/nginx/nginx.conf /data/nginx/conf/nginx.conf 

docker cp nginx:/etc/nginx/conf.d /data/nginx/conf/conf.d 
```
4. 填写配置文件
```
-- 配置SSL

server {
     listen 443; #SSL 访问端口号为 443
		 
     server_name www.dome.com; #填写绑定证书的域名
		 
     ssl on; #启用 SSL 功能
		 
     ssl_certificate /ssl/1_www.dome.com_bundle.crt; #证书文件名称
     ssl_certificate_key /ssl/2_www.dome.com.key; #私钥文件名称

     ssl_session_timeout 5m;
     ssl_protocols TLSv1 TLSv1.1 TLSv1.2; #请按照这个协议配置	 
     ssl_ciphers ECDHE-RSA-AES128-GCM-SHA256:HIGH:!aNULL:!MD5:!RC4:!DHE; #请按照这个套件配置，配置加密套件，写法遵循 openssl 标准。
     ssl_prefer_server_ciphers on;
		 
     #这是我的主页访问地址，因为使用的是静态的html网页，所以直接使用location就可以完成了(填写代理)
     location / {
         root /usr/share/nginx/html; #网站主页路径。此路径仅供参考，具体请您按照实际目录操作（**自己配置**）。
         index  index.html index.htm;
     }
		 
 }
 
#HTTP 自动跳转 HTTPS 的安全配置
server{
  listen 80;
  server_name www.demo.com; #填写绑定证书的域名
  rewrite ^(.*) https://$host$1 permanent; #把http的域名请求转成https
}
```
> PS：可以参考[腾讯云NginxSSL配置](https://cloud.tencent.com/document/product/400/35244)
5. 启动Nginx
```
docker run -d -p 80:80 -p 443:443 --name nginx \
-v /data/nginx/conf/nginx.conf:/etc/nginx/nginx.conf \
-v /data/nginx/conf/conf.d:/etc/nginx/conf.d \
-v /data/nginx/ssl:/ssl/ \
-v /data/nginx/www:/usr/share/nginx/html \
-v /data/nginx/logs:/var/log/nginx nginx
```
> PS：`/data/nginx/www`中可自定义页面

## 结束
