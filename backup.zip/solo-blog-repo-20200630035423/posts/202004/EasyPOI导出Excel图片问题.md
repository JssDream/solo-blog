title: EasyPOI—导出Excel图片问题
date: '2020-04-27 14:50:59'
updated: '2020-04-28 19:35:14'
tags: [SpringBoot, 随记, Java]
permalink: /articles/2020/04/27/1587970259806.html
---
![0047301582390050f40d.jpg](https://img.hacpai.com/file/2020/04/0047301582390050f40d-cd3c3143.jpg)

## 序

今天导出Excel使用EasyPoi工具，发现图片导出一直报错出现越界问题java.lang.ArrayIndexOutOfBoundsException: 0

## 问题

- 报错java.lang.ArrayIndexOutOfBoundsException: 0或ExcelExportException: Excel导出错误

```
cn.afterturn.easypoi.exception.excel.ExcelExportException: Excel导出错误
	at cn.afterturn.easypoi.excel.export.base.BaseExportService.createCells(BaseExportService.java:147) ~[easypoi-base-3.2.0.jar!/:na]
	at cn.afterturn.easypoi.excel.export.ExcelExportService.insertDataToSheet(ExcelExportService.java:178) [easypoi-base-3.2.0.jar!/:na]
	at cn.afterturn.easypoi.excel.export.ExcelExportService.createSheetForMap(ExcelExportService.java:145) [easypoi-base-3.2.0.jar!/:na]
	at cn.afterturn.easypoi.excel.export.ExcelExportService.createSheet(ExcelExportService.java:115) [easypoi-base-3.2.0.jar!/:na]
	at cn.afterturn.easypoi.excel.ExcelExportUtil.exportExcel(ExcelExportUtil.java:87) [easypoi-base-3.2.0.jar!/:na]
	at com.haier.hzy.admin.util.excel.ExcelUtils.defaultExport(ExcelUtils.java:49) [classes!/:1.0.0]
	at com.haier.hzy.admin.util.excel.ExcelUtils.exportExcel(ExcelUtils.java:40) [classes!/:1.0.0]
	at com.haier.hzy.weixin.controller.ActiveBackController.exportTopic(ActiveBackController.java:227) [classes!/:1.0.0]
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method) ~[na:1.8.0_232]
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62) ~[na:1.8.0_232]
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43) ~[na:1.8.0_232]
	at java.lang.reflect.Method.invoke(Method.java:498) ~[na:1.8.0_232]
	at org.springframework.web.method.support.InvocableHandlerMethod.doInvoke(InvocableHandlerMethod.java:189) [spring-web-5.1.3.RELEASE.jar!/:5.1.3.RELEASE]

java.lang.ArrayIndexOutOfBoundsException: 0
	at cn.afterturn.easypoi.util.PoiPublicUtil.getFileExtendName(PoiPublicUtil.java:147) ~[easypoi-base-3.2.0.jar!/:na]
	at cn.afterturn.easypoi.excel.export.base.BaseExportService.getImageType(BaseExportService.java:336) ~[easypoi-base-3.2.0.jar!/:na]
	at cn.afterturn.easypoi.excel.export.base.BaseExportService.createImageCell(BaseExportService.java:190) ~[easypoi-base-3.2.0.jar!/:na]
	at cn.afterturn.easypoi.excel.export.base.BaseExportService.createImageCell(BaseExportService.java:164) ~[easypoi-base-3.2.0.jar!/:na]
	at cn.afterturn.easypoi.excel.export.base.BaseExportService.createCells(BaseExportService.java:123) ~[easypoi-base-3.2.0.jar!/:na]
	at cn.afterturn.easypoi.excel.export.ExcelExportService.insertDataToSheet(ExcelExportService.java:178) ~[easypoi-base-3.2.0.jar!/:na]
	at cn.afterturn.easypoi.excel.export.ExcelExportService.createSheetForMap(ExcelExportService.java:145) ~[easypoi-base-3.2.0.jar!/:na]
	at cn.afterturn.easypoi.excel.export.ExcelExportService.createSheet(ExcelExportService.java:115) ~[easypoi-base-3.2.0.jar!/:na]
	at cn.afterturn.easypoi.excel.ExcelExportUtil.exportExcel(ExcelExportUtil.java:87) ~[easypoi-base-3.2.0.jar!/:na]
	at com.haier.hzy.admin.util.excel.ExcelUtils.defaultExport(ExcelUtils.java:49) ~[classes!/:1.0.0]
	at com.haier.hzy.admin.util.excel.ExcelUtils.exportExcel(ExcelUtils.java:40) ~[classes!/:1.0.0]
	at com.haier.hzy.weixin.controller.ActiveBackController.exportTopic(ActiveBackController.java:227) ~[classes!/:1.0.0]
```

## 原因

> 最后网上发现一篇文章 [https://blog.csdn.net/qq_34988540/article/details/83050187](https://blog.csdn.net/qq_34988540/article/details/83050187) 解释的很详细，包括源码！

主要原因：

`````````````````````````
图片的URL为空导致
`````````````````````````

> 可以看到是在ImageIO.write()我们图片url的时候得到了一个空的字节数组。
> 那么问题出来了，这里为什么返回了一个空的字节数组。从write方法的三个参数中的第二个参数我们可以看到这里将图片路径进行了字符串截取，截取的是第一个点以后的字符串，显然这是在截取图片的后缀名。
> 因为我们使用的图片路径为http://192.168.25.133/group1/M00/00/01/wKgZhVvC78SAfpWaAAAsAp7EzlE763.jpg。 随意第一个点之后的字符串显然有问题，所以这里应该截取最后一个点后面的字符串。

> Easypoi的ImageCache为我们提供了setLoadingCache()方法，使得我们可以设置自己想要的loadingCache，所以，我们只需要自己重写一个loadingCache并赋值给ImageCache。
> 我们可以在Spring容器启动后把这个自定义的loadingCache赋值给ImageCache。

## 解决

```
package com.haier.hzy.admin.util.excel.listener;
 
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.concurrent.TimeUnit;
 
import javax.imageio.ImageIO;
 
import org.apache.poi.util.IOUtils;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;
 
import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
 
import cn.afterturn.easypoi.cache.ImageCache;
import cn.afterturn.easypoi.cache.manager.POICacheManager;
 
@Component
public class ExcelListener implements ApplicationListener<ApplicationReadyEvent>{
 
	@Override
	public void onApplicationEvent(ApplicationReadyEvent event) {
		 LoadingCache<String, byte[]> loadingCache = CacheBuilder.newBuilder().expireAfterWrite(1, TimeUnit.DAYS)
		            .maximumSize(2000).build(new CacheLoader<String, byte[]>() {
		                @Override
		                public byte[] load(String imagePath) throws Exception {
		                    InputStream is = POICacheManager.getFile(imagePath);
		                    BufferedImage bufferImg = ImageIO.read(is);
		                    ByteArrayOutputStream byteArrayOut = new ByteArrayOutputStream();
		                    try {
		                        ImageIO.write(bufferImg,
		                            imagePath.substring(imagePath.lastIndexOf(".")+1),
		                            byteArrayOut);
		                        return byteArrayOut.toByteArray();
		                    } finally {
		                        IOUtils.closeQuietly(is);
		                        IOUtils.closeQuietly(byteArrayOut);
		                    }
		                }
		            });
		ImageCache.setLoadingCache(loadingCache);
	}
 
}
```

## 吐槽

这个问题好像很久了，目前easypoi版本都是4.0了，好像还是没有修复！归根结底就是URL截取问题！

最后好像webp图片还不能解析，网上资料需要单独解析，没做深究，自行研究！
