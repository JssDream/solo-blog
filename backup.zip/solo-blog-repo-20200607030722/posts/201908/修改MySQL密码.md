title: 修改MySQL密码
date: '2019-08-27 11:54:56'
updated: '2019-08-27 11:54:56'
tags: [魔鬼命令, MySQL, 随记]
permalink: /articles/2019/08/27/1566878096384.html
---
![](https://img.hacpai.com/bing/20181219.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 环境
	使用的`docker`安装`MySQL`，版本`8.0.12`
## 操作
	
* 首先进入`docker`的`MySQL`容器:

> 使用命令`docker exec -it mysql /bin/bash`

* 进入容器之后，登录到`MySQL`里面：

>```
>root@1f88cc6f4013:/# mysql -u root -p
>Enter password: 
>```

* 输入密码之后，可以查询下目前的用户密码：

> ```
> mysql> select host,user,authentication_string from mysql.user;
> ```
![image.png](https://img.hacpai.com/file/2019/08/image-a2818c58.png)

>	host: 允许用户登录的ip‘位置'%表示可以远程；
	user:当前数据库的用户名；
	authentication_string: 用户密码（后面有提到此字段）；

**重点**

1. 如果当前root用户authentication_string字段下有内容，先将其设置为空，否则直接进行二步骤

>```
>use mysql;
>update user set authentication_string='' where user='root';
>```
2. 使用ALTER修改root用户密码,方法为 ALTER user 'root'@'localhost' IDENTIFIED BY '新密码'：

>```
>ALTER user 'root'@'localhost' IDENTIFIED BY '123456';
>ALTER user 'root'@'%' IDENTIFIED BY '123456'
>```
修改成功，退出重启容器，重新连接就可以了

**PS**：`MySQL8.0`以后使用的秘钥插件是`caching_sha2_password`，以前使用的都是`mysql_native_password`，所以有可能出现`Navicat`链接失败的错误，可以使用如下命令：

> ```
> ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY '新密码';
> FLUSH PRIVILEGES;
> ```
