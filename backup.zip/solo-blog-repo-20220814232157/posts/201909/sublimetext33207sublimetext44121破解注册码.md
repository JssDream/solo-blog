title: sublime text 3 3207/sublime text 4 4121 破解+注册码
date: '2019-09-26 17:52:01'
updated: '2021-12-25 21:52:45'
tags: [随记, Tools, 分享]
permalink: /articles/2019/09/26/1569491521771.html
---
![](https://img.hacpai.com/bing/20190712.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 步骤

### sublime text 3 破解

1. 安装`sublime text 3`，至于软件，[官网下载](http://www.sublimetext.com/3)
2. 傻瓜式安装，next最后
3. 打开[https://hexed.it/](https://hexed.it/) 备用
4. 打开`sublime text`的安装目录，然后备份一下` sublime_text.exe`![image.png](https://img.hacpai.com/file/2019/09/image-8c156def.png)
5. 在刚刚的网站上面点击`Open file` 并选择自己安装的`sublime_text.exe `可执行文件![image.png](https://img.hacpai.com/file/2019/09/image-1b4c76e1.png)
6. 转到`Search for` 框, 输入`97 94` 并点击`Search now`进行搜索![image.png](https://img.hacpai.com/file/2019/09/image-704209bc.png)
7. 依次点击查看搜索结果，查看是否出现`97 94 0D`，如果看到`97 94 0D`， 将它改为`00 00 00`![image.png](https://img.hacpai.com/file/2019/09/image-499fe3d1.png)
8. 然后点击`Export`"并保存到本地，替换源文件

### sublime text 4 破解

**2021年7月14日 最新更新！**

**软件版本 4113 依此替换下方 2 组字节！**
`C3 C6 01 00 C3` 替换为 `C3 C6 01 01 C3`
`51 31 C0 88 05` 替换为 `51 b0 01 88 05`

**2021年12月25日 最新版本 Sublime Text 4 Build 4121/4126，按步骤操作！**

**第一步：**

X64版本

`4157415656575553B828210000` 替换为 `33C0FEC0C3575553B828210000`

X86版本
`55535756B8AC200000` 替换为 `33C0FEC0C3AC200000`

**第二步：**
`6C6963656E73652E7375626C696D6568712E636F6D` 替换为 `7375626C696D6568712E6C6F63616C686F73740000`

**第三步：替换exe后用以下注册码激活**

```
----- BEGIN LICENSE -----
RUYO.net
Unlimited User License
EA7E-81044230
0C0CD4A8 CAA317D9 CCABD1AC 434C984C
7E4A0B13 77893C3E DD0A5BA1 B2EB721C
4BAAB4C4 9B96437D 14EB743E 7DB55D9C
7CA26EE2 67C3B4EC 29B2C65A 88D90C59
CB6CCBA5 7DE6177B C02C2826 8C9A21B0
6AB1A5B6 20B09EA2 01C979BD 29670B19
92DC6D90 6E365849 4AB84739 5B4C3EA1
048CC1D0 9748ED54 CAC9D585 90CAD815
------ END LICENSE ------
```

## 更改 host 文件

`C:\Windows\System32\Drivers\etc`

> 添加下面两行：

* 127.0.0.1 license.sublimehq.com # SublimeText
* 127.0.0.1 www.sublimetext.com  # SublimeText

## 最后打开 sublime，输入以下许可证：

```
----- BEGIN LICENSE -----
TwitterInc
200 User License
EA7E-890007
1D77F72E 390CDD93 4DCBA022 FAF60790
61AA12C0 A37081C5 D0316412 4584D136
94D7F7D4 95BC8C1C 527DA828 560BB037
D1EDDD8C AE7B379F 50C9D69D B35179EF
2FE898C4 8E4277A8 555CE714 E1FB0E43
D5D52613 C3D12E98 BC49967F 7652EED2
9D2D2E61 67610860 6D338B72 5CF95C69
E36B85CC 84991F19 7575D828 470A92AB
------ END LICENSE ------
```

## 收工

