title: Spring Boot——@SpringBootApplication(exclude = DataSourceAutoConfiguration.class)
date: '2019-10-30 18:37:39'
updated: '2019-10-30 18:38:17'
tags: [SpringBoot, 随记]
permalink: /articles/2019/10/30/1572431859394.html
---
![](https://img.hacpai.com/bing/20180103.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 分析

在Spring Boot中启动类是默认加载数据库配置的

* 如果在启动类的配置上加了注解`@SpringBootApplication(exclude= DataSourceAutoConfiguration.class)`，项目也没有自己配置自定义DataSource那么在项目启动的时候会报数据源找不到

* 还有一种可能是在application.properties压根没有配置数据库配置，也会报数据源找不到
```  
***************************  
APPLICATION FAILED TO START  
***************************  
  
Description:  
  
Failed to configure a DataSource: 'url' attribute is not specified and no embedded datasource could be configured.  
  
Reason: Failed to determine a suitable driver class  
```
## 备注
> 在Spring Boot 中配置Dubbo的时候，在消费者模块不需要配置数据库信息，这个时候在启动类上面添加注解
`@SpringBootApplication(exclude= DataSourceAutoConfiguration.class)`没有问题！



