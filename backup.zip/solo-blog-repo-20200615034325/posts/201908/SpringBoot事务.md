title: Spring Boot事务
date: '2019-08-27 18:31:42'
updated: '2019-08-27 18:32:54'
tags: [SpringBoot, 事务Transaction, 随记]
permalink: /articles/2019/08/27/1566901901979.html
---
![](https://img.hacpai.com/bing/20190711.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 关于`Spring Boot`启用事务：
	
1.开启事务管理
> 在启动类上面加事务管理注解：
>```
>@EnableTransactionManagement // 启注解事务管理，等同于xml配置方式的 <tx:annotation-driven />
>```
2.事务注解详解
>在service方法上面添加`@Transactional`注解

## `@Transactional`注解失效说明

* 数据库引擎中`MyIsam`不支持事务，必须是`InnnoDB`引擎

* `@Transactional`所注解的方法只有是`public`才起作用

* `@Transactional`所注解的方法所在的类，必须注解`@Service`或`@Component`等

* 需要调用该方法，且需要支持事务特性的调用方是在 `@Transactional`所在的类的外面。注意：类内部的其他方法调用这个注解了`@Transactional`的方法，事务是不会起作用的。

* @Transactional注解事务范围，并不是所有异常都可以进行数据回滚，他只有是`RuntimeException`类及其子类（中文称为：运行时异常/`unchecked`异常/未检异常）异常的时候才会进行数据回滚。简单的说`@Transactional`注解只有抛出`RuntimeException`类及其子类异常（中文称为：运行时异常/unchecked异常/未检异常）才能回滚，其他的所有异常都不行，当然出现`Error`的时候也是会回滚的

	>如果希望一般的异常也能触发事务回滚，需要在注解了@Transactional的方法上，将@Transactional回滚参数设为:
	>```
	>@Transactional(rollbackFor=Exception.class)
	>```
	>手动回滚事务：可以在service层方法的`catch `加 
	>```
	>TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
	>```

## 备注
	
>待补充.......
