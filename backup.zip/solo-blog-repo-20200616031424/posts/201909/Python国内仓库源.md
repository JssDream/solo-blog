title: Python国内仓库源
date: '2019-09-21 17:57:42'
updated: '2019-09-21 17:57:42'
tags: [Python, 随记]
permalink: /articles/2019/09/21/1569059862194.html
---
![](https://img.hacpai.com/bing/20190811.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## :huaji: 

今天玩了下python，发现有些库下载不下来，然后找了些国内的仓库地址：

* [阿里云](https://mirrors.aliyun.com/pypi/simple/)  PS：有的好像没有,今天安装`requests`库没成功，用的豆瓣的
	https://mirrors.aliyun.com/pypi/simple/
* [清华大学](https://pypi.tuna.tsinghua.edu.cn/simple/)  **好像挂了，反正在公司没打开**
	https://pypi.tuna.tsinghua.edu.cn/simple/
* [豆瓣(douban) ](https://pypi.doubanio.com/simple/)
	https://pypi.doubanio.com/simple/
* [中国科学技术大学](https://pypi.mirrors.ustc.edu.cn/simple/)  **好像挂了，反正在公司没打开**
	https://pypi.mirrors.ustc.edu.cn/simple/
* [中国科技大学](https://pypi.mirrors.ustc.edu.cn/simple/)  **好像挂了，反正在公司没打开**
	https://pypi.mirrors.ustc.edu.cn/simple/

