title: Linux定时备份Docker的MySQL数据库
date: '2019-08-28 16:13:30'
updated: '2019-08-28 16:16:53'
tags: [Linux, 魔鬼命令, 随记]
permalink: /articles/2019/08/28/1566980010076.html
---
![](https://img.hacpai.com/bing/20171105.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 论备份的重要性

>最近遇到了好几个网友出现`MySQL`数据库勒索事件，本人前两天也遇到，事情大概这样子的：
	大早上起来，打开网站，发现500错误，这就很尴尬了，感觉查看日志发现怪事,数据库找不到了(PS：心里很慌，原因之前就想着备份，一直给忘了)	打开数据库真的不见了，多了一个不知道的库，里面有一张WARNING表,内容全是英文(PS：额，看不懂)，去翻译，彻底惊呆了！比特币勒索（PS：心里一万个小马跑过）

![image.png](https://img.hacpai.com/file/2019/08/image-5d564204.png)
![image.png](https://img.hacpai.com/file/2019/08/image-6a043403.png)

	接着百度发现在17年的时候又一波比特币勒索事件，好多数据库都被黑了，要求花钱赎回......
	这件事情让我认识到数据库备份的重要性，哎，赶紧重新搞一套出来，幸亏博文都有备份，哈哈...
## 解决

>由于本人使用的是`docker`部署的`MySQL`，所以去百度命令
	```
	docker exec -it mysql mysqldump -uroot -p123456 databases > /backup/data_`date +%Y%m%d%H%M%S`.sql;
	```
拿着命令去跑了下，可以备份，完美

## 定时备份
	
>想着不能每天手动处理吧，然后就做了一个定时任务，每天备份一次，不说了，上操作：
1. 新建脚本mysql_bak.sh，将以下命令粘贴；
```
# mysql 为安装mysql的docker
#!/bin/bash
docker_name=mysql
data_dir="/data/backup/mysql/"
docker exec -it $docker_name mysqldump -uroot -p123456 --all-databases > "$data_dir/solo_`date +%Y%m%d%H%M%S`.sql"
# 删除7天以前的备份
find $data_dir -mtime +7 -name 'solo_*.sql' -exec rm -rf {} \;
```
**备注**

* `docker_name`:`MySQL`容器名称
* `data_dir`:保存路径
* `--all-databases`:表示所有的数据库都备份，可以备份固定的数据库，直接替换就可以了
* `-mtime +7`: 按照文件的更改时间来查找文件，+7表示文件更改时间距现在7天以前；如果是 -mmin +7表示文件更改时间距现在7分钟以前
*`-exec rm -rf {} `;   表示执行一段shell命令，exec选项后面跟随着所要执行的命令或脚本，然后是一对儿{}，一个空格和一个，最后是一个分号

2.在定时任务中添加新的任务规则，`crontab -e`,将下面命令写入并报存:wq
```
0 0 * * * /bin/sh /data/mysql_bak.sh >> /data/logs/mysql_bak.log 2>&1

PS：/data/logs/mysql_bak.log ：输出日志
```

## 结束

**学习是一种进步态度，笔记是一种成长的动作**
