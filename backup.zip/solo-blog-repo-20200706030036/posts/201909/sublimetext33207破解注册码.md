title: sublime text 3 3207 破解+注册码
date: '2019-09-26 17:52:01'
updated: '2019-09-26 17:54:05'
tags: [随记, Tools, 分享]
permalink: /articles/2019/09/26/1569491521771.html
---
![](https://img.hacpai.com/bing/20190712.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 步骤


1. 安装`sublime text 3`，至于软件，[官网下载](http://www.sublimetext.com/3)

2. 傻瓜式安装，next最后

3. 打开 [https://hexed.it/](https://hexed.it/) 备用

4. 打开`sublime text`的安装目录，然后备份一下` sublime_text.exe`
![image.png](https://img.hacpai.com/file/2019/09/image-8c156def.png)

5. 在刚刚的网站上面点击`Open file` 并选择自己安装的 `sublime_text.exe `可执行文件
![image.png](https://img.hacpai.com/file/2019/09/image-1b4c76e1.png)

6. 转到 `Search for` 框, 输入 `97 94` 并点击`Search now`进行搜索
![image.png](https://img.hacpai.com/file/2019/09/image-704209bc.png)

7. 依次点击查看搜索结果，查看是否出现 `97 94 0D`，如果看到 `97 94 0D`， 将它改为 `00 00 00`
![image.png](https://img.hacpai.com/file/2019/09/image-499fe3d1.png)

8. 然后点击 `Export`"并保存到本地，替换源文件

## 更改 host 文件

`C:\Windows\System32\Drivers\etc`

> 添加下面两行：

* 127.0.0.1 license.sublimehq.com # SublimeText
* 127.0.0.1 www.sublimetext.com  # SublimeText

## 最后打开 sublime，输入以下许可证：

```
----- BEGIN LICENSE -----
TwitterInc
200 User License
EA7E-890007
1D77F72E 390CDD93 4DCBA022 FAF60790
61AA12C0 A37081C5 D0316412 4584D136
94D7F7D4 95BC8C1C 527DA828 560BB037
D1EDDD8C AE7B379F 50C9D69D B35179EF
2FE898C4 8E4277A8 555CE714 E1FB0E43
D5D52613 C3D12E98 BC49967F 7652EED2
9D2D2E61 67610860 6D338B72 5CF95C69
E36B85CC 84991F19 7575D828 470A92AB
------ END LICENSE ------
```
## 收工
