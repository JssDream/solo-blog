title: Spring Cloud版本号
date: '2020-08-20 15:47:18'
updated: '2020-08-20 15:48:10'
tags: [随记, SpringCloud]
permalink: /articles/2020/08/20/1597909638127.html
---
![20190909175734.jpg](https://b3logfile.com/file/2020/08/20190909175734-d4caf10a.jpg)

## 序
Spring Cloud使用的版本号是英文方式，而不是传统的数字版本，为什么呢。因为Spring Cloud是微服务的解决方案，他会有很多子项目，每个子项目都维护这自己的版本号，为了避免冲突，就使用了伦敦地铁站的名字作为版本号。以首字母作为顺序，a,b,c,d....排列。
### 说明
现有版本号：Angel、Brixton、Camden、Daston、Edgware、Finchley、GreenWich、Hoxton。
 
### 扩展
#### 常见版本号说明

> 例如 2.1.13.RELEASE

其中Release的意思是最终版本，除此之外：

- Base：设计阶段。只有相应的设计没有具体的功能实现。

- Alpha：软件的初级版本。基本功能已经实现，但存在较多的bug。

- Bate：相对于Alpha已经有了很大的进步，消除了严重的BUG，但还存在一些潜在的BUG，还需要不断测试。

- RELEASE：最终版本，没有太大的问题。

#### Spring Cloud 版本后缀

- BUILD-XXX　　　　　开发版　　　　开发团队内部使用，不是很稳定
- GA　　　　　　　　　稳定版　　　　相比于开发版，基本上可以使用了
- PRE（M1、M2）　　  里程碑版　　　主要是修复了一些BUG的版本，一个GA后通常有多个里程碑版
- RC　　　　　　　　　候选发布版　　该阶段的软件类似于最终版的一个发行观察期，基本只修复比较严重的BUG
- SR　　　　　　　　    正式发布版　　


另外，springcloud和springboot的版本有相应的对应关系，如果不对应会出现问题。

具体关系可以查看：https://start.spring.io/info
