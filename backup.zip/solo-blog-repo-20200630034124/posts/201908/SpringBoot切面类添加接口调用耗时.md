title: Spring Boot切面类添加接口调用耗时
date: '2019-08-28 19:39:04'
updated: '2019-08-28 19:39:04'
tags: [SpringBoot, Spring, 随记]
permalink: /articles/2019/08/28/1566992344180.html
---
## 笔记

```
/**
 * 增加方法调用好事
 */
@Component
@Aspect //标注增强处理类（切面类）
public class AdminTimeAspect {

    private Logger log = LoggerFactory.getLogger(AdminTimeAspect.class);

    //可自定义切点位置，针对不同切点，方法上的@Around()可以这样写ex：@Around(value = "methodPointcut() && args(..)")
    @Around("execution (* com.xxx.controller..*.*(..))")
    public Object doAround(ProceedingJoinPoint joinPoint) throws Throwable{

        long start = System.currentTimeMillis();
        try {

            Object result = joinPoint.proceed();
            long end = System.currentTimeMillis();
            long duration = end - start;
            log.info("【调用方法】 " + joinPoint + "\t【耗时】 : " + (duration) + " ms!");
            return result;

        } catch (Throwable e) {
            long end = System.currentTimeMillis();
            log.info("【调用方法】 " + joinPoint + "\t【耗时】 : " + (end - start) + " ms with exception : " + e.getMessage());
            throw e;
        }
    }

}
```
PS:
* 任意公共方法的执行：execution(public * *(..))
* 任何一个以“set”开始的方法的执行：execution(* set*(..))
* TestService 接口的任意方法的执行：execution(* com.xxx.service.TestService.*(..))
* 定义在service包里的任意方法的执行： execution(* com.xxx.service.*.*(..))
* 定义在service包和所有子包里的任意类的任意方法的执行：execution(* com.xxx.service..*.*(..))

**`@Around`的作用**
	
* 既可以在目标方法之前织入增强动作，也可以在执行目标方法之后织入增强动作；
* 可以决定目标方法在什么时候执行，如何执行，甚至可以完全阻止目标目标方法的执行；
* 可以改变执行目标方法的参数值，也可以改变执行目标方法之后的返回值； 当需要改变目标方法的返回值时，只能使用Around方法；

虽然Around功能强大，但通常需要在线程安全的环境下使用。因此，如果使用普通的Before、AfterReturing增强方法就可以解决的事情，就没有必要使用Around增强处理了。
