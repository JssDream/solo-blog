title: GitHub 沙雕项目
date: '2020-07-30 20:35:25'
updated: '2020-07-31 10:33:19'
tags: [分享, GitHub, 随记]
permalink: /articles/2020/07/30/1596112525485.html
---
![12072014937844406f9f.jpg](https://b3logfile.com/file/2020/07/12072014937844406f9f-39ade879.jpg)

## 序

> 今天推送几个沙雕项目，太秀了🤣 ，找几个过于沙雕的分享给大家。

## GitHub

### logoly

- **Star: 5.2k**
- **项目地址：** https://github.com/bestony/logoly

这个项目是一个简易的 logo 生成器，能生成下图类似风格的 logo。下图中关键部分做了马赛克处理 :trollface:

![图片.png](https://b3logfile.com/file/2020/07/图片-9813bf7f.png)

经常刷小破站的读者应该经常看到类似风格的视频封面，比如下图圈出来的封面。估计这种风格的封面是半佛老师的最爱呀～

![图片.png](https://b3logfile.com/file/2020/07/图片-6c82800f.png)

（不仅仅是B站，经常逛 P 站的朋友肯定见过这个风格的logo ）

**如何生成自己的 logo**

* 打开Logoly网站：https://logoly.pro/
* 在框中编辑文本
* 根据需要更改颜色和字体大小
* 单击导出按钮以下载图像

### Dress

* **Star: 17.7k**
* **项目地址：** https://github.com/komeiji-satori/Dress

你可能想不到这个 17.7k star 的项目是一个**面向可爱的蓝孩子**的 git 学习实践项目 。

该项目对贡献者的要求不高，并不要求你贡献代码，没有编程技能都可以参加。你可以从这里学习从克隆项目，创建分支，提交和同步修改，到合并分支请求的整套流程，一次即可熟悉 Git/GitHub 的使用。

但是：**你还要事先准备至少一张你的女装照。**

没错，这就是女装大佬集结地，截止目前为止，已经有 两百多名大佬上传过女装照，并且有 1103 次提交。光看贡献者的头像，二次元风格满满。本来想找几张给大家养养眼，打开后发现顶不住啊，溜了溜了。。。

![图片.png](https://b3logfile.com/file/2020/07/图片-d7814f29.png)

想在简历里写上：参与过Github 10000+ starts的项目，那你就PR这个吧

### 灭霸脚本

* **Star : 2k**
* **项目地址：** https://github.com/hotvulcan/Thanos.sh

![](https://b3logfile.com/file/2020/07/solofetchupload2730086729904613691-66009904.jpeg)
一个开源的个灭霸命令，可随机删除电脑上一半文件

**PS**：请不要在家里或其他地方使用。这是**真家伙**，要小心…

### wenyan

* **Star: 16.2 k**
* **项目地址：** https://github.com/wenyan-lang/wenyan

这是一个文言文編程語言，没错，文言文。。。你以为只是玩玩？你想多了，还有配套的 ide：https://ide.wy-lang.org/ 下图是一个快速排序的

![图片.png](https://b3logfile.com/file/2020/07/图片-499f2350.png)

**Helloworld**
Wenyan:

```
吾有一數。曰三。名之曰「甲」。
為是「甲」遍。
	吾有一言。曰「「問天地好在。」」。書之。
云云。
```

Equivalent JavaScript:

```js
var n = 3;
for (var i = 0; i < n; i++) {
	console.log("問天地好在。");
}
```

Output:

```
問天地好在。
問天地好在。
問天地好在。
```

### dongbei

* **Star: 1.4 k**
* **项目地址：** https://github.com/zhanyong-wan/dongbei

刚刚是文言文编程语言，这个是东北方言编程。体验一下东北方言编程的 hello word。

**吃了没，老铁**

创建一个名字叫 hello-world.dongbei 的文本文件，内容如下：

`唠唠：“唉呀，这嘎哒真他妈那啥！”。`

用 utf-8 编码保存。要是编辑器因为编码有毛病埋汰你，那就把文件内容改成

```
# -*- coding: utf-8 -*-
唠唠：“唉呀，这嘎哒真他妈那啥！”。
```

再试，应该就成了。

然后在命令行窗口运行：

`dongbei hello-world.dongbei`

你应该看到执行结果：

`唉呀，这嘎哒真他妈那啥！`

### 一行代码没有

* **Star 42.6k**
* **项目地址：** https://github.com/kelseyhightower/nocode

> 项目理念：没有代码是编写安全可靠的应用程序的最佳方法。什么也不要写，也不用部署。

**Hello Word：**

**入门**

首先不编写任何代码。

```

```

这只是一个示例应用程序，但是请想象它可以做任何您想做的事情。添加新功能也很容易：

```

```

一切皆有可能！

**构建应用程序**

现在您还没有做任何事情，现在是时候构建您的应用程序了：

```

```

您应该看到以下输出：

```

```

**部署**

尽管你没有做任何事情，但是现在该部署应用程序了。通过运行以下命令部署你的应用程序。

```

```

就这么简单。当需要扩展应用程序时，你要做的就是：

```

```

酷不酷？

这个项目啥都没有，就有 42.5k Star，而且 Issues 竟然也有 3.2k，集体装逼盛宴！翻了几页，大家体会一下：

- 代码之源

![图片.png](https://b3logfile.com/file/2020/07/图片-a8729f41.png)

- 心中自然无码

![图片.png](https://b3logfile.com/file/2020/07/图片-db9a35c7.png)

- 无，即是万物

![图片.png](https://b3logfile.com/file/2020/07/图片-da178c05.png)

- 皇帝的新码

![图片.png](https://b3logfile.com/file/2020/07/图片-bc2a5fe1.png)

### FakeScreenshot

* **Star: 951**
* **项目地址：** https://github.com/thegreatjavascript/FakeScreenshot

>

> 这是一个可以**伪造任何网站界面截图**的工具。
>
> 但本工具的目的其实不是破坏，而是为了警告（不懂编程的）普通人：**不要轻易相信网上看到的“截图”！****2020-4-26：突破性更新**，可以修改任何网站的任何文字/图片。

![basic](https://github.com/thegreatjavascript/FakeScreenshot/raw/master/preview/basic.gif)![basic](https://github.com/thegreatjavascript/FakeScreenshot/raw/master/preview/dialog.gif)![basic](https://github.com/thegreatjavascript/FakeScreenshot/raw/master/preview/picture.gif)

很有意思的一个截图工具！！！

### seq2seq-couplet

* **Star 4.5k**
* **项目地址：** https://github.com/wb14123/seq2seq-couplet
  一个有趣的对对联工具，用深度学习对对联

![图片.png](https://b3logfile.com/file/2020/07/图片-cd5a9e7d.png)

[在线体验](https://ai.binwang.me/couplet/)

### chinese-poetry

- **Star 29.5k**
- **项目地址：** https://github.com/chinese-poetry/chinese-poetry

> 最全中华古诗词数据库, 唐宋两朝近一万四千古诗人, 接近5.5万首唐诗加26万宋诗. 两宋时期1564位词人，21050首词。

![图片.png](https://b3logfile.com/file/2020/07/图片-b810d4ad.png)

[浏览地址](https://shici.store/huajianji/)

### profile-summary-for-github

- **Star 19.1k**
- **项目地址：** https://github.com/tipsy/profile-summary-for-github

> Tool for visualizing GitHub profiles(图像化展示Github账号的信息)

![screenshot](https://b3logfile.com/file/2020/07/solofetchupload3962234425586552932-7508cab1.png)

[体验地址](https://profile-summary-for-github.com/)

PS：这个很Nice,可以再GitHub首页使用试试

### carbon

- **Star 24.8k**
- **项目地址：** https://github.com/carbon-app/carbon

> **代码转换成图片**

![图片.png](https://b3logfile.com/file/2020/07/图片-f8c392d3.png)

更多有趣项目：https://www.zhihu.com/question/23498424
