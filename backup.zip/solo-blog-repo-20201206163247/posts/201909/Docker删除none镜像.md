title: Docker删除none镜像
date: '2019-09-19 20:26:51'
updated: '2019-09-19 20:27:13'
tags: [Linux, 随记, Docker]
permalink: /articles/2019/09/19/1568896011749.html
---
![](https://img.hacpai.com/bing/20180912.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

## 起因

最近发现Docker的相同容器多了几个，这样就会多出好多无用的镜像，所以需要删除，查了下none镜像产生的原因：
>有时候重新构建镜像的时候，该镜像正在被某容器使用中，那么在重新构建同名同版本镜像后，docker保留原来的镜像，即容器还是用原来的，除非重启。
那么原来的镜像名称变成NONE，TAG也成了NONE

看到这里就想到应该是之前的定时脚本引起的，，，
## 解决

命令：
* 列出所有的镜像
>```
>docker images -a
>```
![image.png](https://img.hacpai.com/file/2019/09/image-3593e4b9.png)

* 列出所有的容器
>```
>docker ps -a
>```

* 列出所有的容器 ID

>```
>docker ps -a -q
>```

* 停止所有的容器

>```
>docker stop $(docker ps -a -q)
>```

* 批量删除tag为"<none>"镜像

>```
>docker rmi $(docker images | grep "<none>" | awk "{print $3}")
>```
PS:说明 
1. `docker images | grep "<none>"`	查询所有为`<none>`的镜像
2. `awk "{print $3}"` 输出第三列

* 删除所有停止的容器

>```
> docker rm $(docker ps -a -q)
>```

* 查询所有的镜像的`IMAGE ID`：

>```
> docker images -q
>```

* 删除所有的镜像：

>```
> docker rmi $(docker images -q)
>```

## 结束

