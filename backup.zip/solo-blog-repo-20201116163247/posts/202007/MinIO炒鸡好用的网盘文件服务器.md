title: MinIO-炒鸡好用的网盘+文件服务器
date: '2020-07-24 16:12:27'
updated: '2020-07-24 16:12:27'
tags: [MinIO, 文件服务器]
permalink: /articles/2020/07/24/1595578346772.html
---
![00184915912011292fcb.jpg](https://b3logfile.com/file/2020/07/00184915912011292fcb-f8bef089.jpg)

## 简介

>MinIO 是一个基于Apache License v2.0开源协议的对象存储服务。它兼容亚马逊S3云存储服务接口，非常适合于存储大容量非结构化的数据，例如图片、视频、日志文件、备份数据和容器/虚拟机镜像等，而一个对象文件可以是任意大小，从几kb到最大5T不等。
MinIO是一个非常轻量的服务,可以很简单的和其他应用的结合，类似 NodeJS, Redis 或者 MySQL

### 优点

- 支持分布式存储，具备高扩展性、高可用性
- 部署简单但功能丰富 通过 `docker` 方式部署
- 官方的文档也很详细 [`MinIO`](https://docs.min.io/cn/)
- 部署方式多样性(单机部署，分布式部署)

## 部署

推荐使用 `docker` 一键安装：

```
docker run -it -p 9000:9000 --name minio \
-d --restart=always \
-e "MINIO_ACCESS_KEY=admin" \
-e "MINIO_SECRET_KEY=12345678" \
-v /data/minio/data:/data \
-v /data/minio/config:/root/.minio \
minio/minio server /data
```

注意：

* 密钥必须大于8位，否则会创建失败
* 文件目录和配置文件一定要映射到主机

### 整合Nginx
```
server{
    listen 80;
    server_name minio.domain.com;
    location /{
        proxy_set_header Host $http_host;
        proxy_pass http://localhost:9000;
    }
    location ~ /\.ht {
        deny  all;
    }
}
```
通过浏览器访问配置的地址，使用指定的 `MINIO_ACCESS_KEY` 及 `MINIO_SECRET_KEY` 登录即可

### 使用

>界面简单，功能齐全，支持创建`Bucket`，文件上传、删除、分享、下载，同时可以对`Bucket`设置读写权限

#### 登录
![图片.png](https://b3logfile.com/file/2020/07/图片-439ff84b.png)

#### 密码修改等
![图片.png](https://b3logfile.com/file/2020/07/图片-f358f9bf.png)

#### Bucket设置读写权限
![图片.png](https://b3logfile.com/file/2020/07/图片-b4dea89d.png)

#### 上传文件和创建Bucket
![图片.png](https://b3logfile.com/file/2020/07/图片-da9fcc85.png)

#### 文件分享等操作
![图片.png](https://b3logfile.com/file/2020/07/图片-e9bbdb8d.png)

