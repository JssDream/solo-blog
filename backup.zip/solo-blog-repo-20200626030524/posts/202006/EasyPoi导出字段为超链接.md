title: EasyPoi导出字段为超链接
date: '2020-06-17 20:24:18'
updated: '2020-06-17 20:24:18'
tags: [随记, EasyPoi]
permalink: /articles/2020/06/17/1592396658708.html
---
![wallhavenymwj9d.jpg](https://b3logfile.com/file/2020/06/wallhavenymwj9d-0a240441.jpg)

## 看文档 http://easypoi.mydoc.io/
### 步骤一
- 字段上面开启超链接
```
@Excel(name = "地址", isHyperlink = true)
private String path;
```
### 步骤二

- 实现拦截类

![image.png](https://b3logfile.com/file/2020/06/image-921070d7.png)

- 代码实现

```
public class ExcelDataHandler extends ExcelDataHandlerDefaultImpl<Object> {
    @Override
    public Hyperlink getHyperlink(CreationHelper creationHelper, Object obj, String name, Object value) {
        Hyperlink hyperlink = creationHelper.createHyperlink(HyperlinkType.URL);
        hyperlink.setLabel(name);
        hyperlink.setAddress((String) value);
        return hyperlink;
    }
}
```
> `Object`为操作类

### 步骤三

- 将拦截类加载导出方法
```
ExportParams exportParams = new ExportParams(title, sheetName);
        exportParams.setDataHandler(new ExcelDataHandler());
        ExportExcelUtil.exportExcel(list, Object.class, fileName, response, exportParams);
```
>`Object`操作模板

### 结束


	


