title: Spring Boot启动自定义Banner
date: '2019-08-20 14:08:00'
updated: '2019-08-20 14:47:33'
tags: [SpringBoot, 趣味编程, 随记]
permalink: /articles/2019/08/20/1566281280069.html
---
![](https://img.hacpai.com/bing/20180207.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

>今天启动项目的时候注意到Spring Boot的启动日志图案，感觉不太好看，想到之前浏览过一篇文章[# 新年彩蛋：Spring Boot自定义Banner](http://blog.didispace.com/spring-boot-banner/)，介绍了Spring Boot启动Banner可以使用自定义图案，学习下，随手记录在此：

## Spring Boot 正常启动效果

![image.png](https://img.hacpai.com/file/2019/08/image-63b7fe98.png)

上图就是Spring Boot 正常启动`Banner`的效果

	`Banner`是`SpringBoot`框架一个特色的部分，其设计的目的无非就是一个框架的标识，其中包含了版本号、框架名称等内容，既然`SpringBoot`为我们提供了这个模块，它肯定也是可以更换的这也是`Spring`开源框架的设计理念。

## 更换Banner效果

![image.png](https://img.hacpai.com/file/2019/08/image-960a70e1.png)

### 操作

	简单创建一个`SpringBoot`框架：在Spring Boot工程的`/src/main/resources`目录下创建一个`banner.txt`文件，然后将ASCII字符画复制进去，就能替换默认的banner了，比如上图中的输出，就采用了下面的`banner.txt`内容：
永不宕机佛祖
```
${AnsiColor.BRIGHT_YELLOW}
////////////////////////////////////////////////////////////////////
//                                                                //
//                          ${AnsiColor.BRIGHT_RED}_ooOoo_${AnsiColor.BRIGHT_YELLOW}                               //
//                         ${AnsiColor.BRIGHT_RED}o8888888o${AnsiColor.BRIGHT_YELLOW}                              //
//                         ${AnsiColor.BRIGHT_RED}88${AnsiColor.BRIGHT_YELLOW}" . "${AnsiColor.BRIGHT_RED}88${AnsiColor.BRIGHT_YELLOW}                              //
//                         (| ^_^ |)                              //
//                         O\  =  /O                              //
//                      ____/`---'\____                           //
//                    .'  \\|     |//  `.                         //
//                   /  \\|||  :  |||//  \                        //
//                  /  _||||| -:- |||||-  \                       //
//                  |   | \\\  -  /// |   |                       //
//                  | \_|  ''\---/''  |   |                       //
//                  \  .-\__  `-`  ___/-. /                       //
//                ___`. .'  /--.--\  `. . ___                     //
//              ."" '<  `.___\_<|>_/___.'  >'"".                  //
//            | | :  `- \`.;`\ _ /`;.`/ - ` : | |                 //
//            \  \ `-.   \_ __\ /__ _/   .-` /  /                 //
//      ========`-.____`-.___\_____/___.-`____.-'========         //
//                           `=---='                              //
//      ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^        //
//            佛祖保佑       永不宕机     永无BUG                 //
////////////////////////////////////////////////////////////////////
${AnsiColor.BRIGHT_RED}
Application Version: ${application.version}${application.formatted-version}
Spring Boot Version: ${spring-boot.version}${spring-boot.formatted-version}

```
从上面的内容中可以看到，还使用了一些属性设置：

* `${AnsiColor.BRIGHT_RED}`：设置控制台中输出内容的颜色
* `${application.version}`：用来获取`MANIFEST.MF`文件中的版本号
* `${application.formatted-version}`：格式化后的`${application.version}`版本信息
* `${spring-boot.version}`：Spring Boot的版本号
* `${spring-boot.formatted-version}`：格式化后的`${spring-boot.version}`版本信息

## 生成工具

如果让我们手工的来编辑这些字符画，显然是一件非常困难的差事。所以，我们可以借助下面这些工具，轻松地根据文字或图片来生成用于Banner输出的字符画。

* [http://patorjk.com/software/taag](http://patorjk.com/software/taag)
* [http://www.network-science.de/ascii/](http://www.network-science.de/ascii/)
* [http://www.degraeve.com/img2txt.php](http://www.degraeve.com/img2txt.php)
* [http://www.makepic.net/tool/image2ascii.html](http://www.makepic.net/tool/image2ascii.html) : **该网站可以将图片转成字符**

## 有趣的图案

![image.png](https://img.hacpai.com/file/2019/08/image-31ab8941.png)

```
${AnsiColor.BRIGHT_RED}                      !                      天地山青   ${AnsiColor.BRIGHT_YELLOW}                      !
${AnsiColor.BRIGHT_RED}                     /^\                        ${AnsiColor.BRIGHT_YELLOW}道法无常                     /^\
${AnsiColor.BRIGHT_RED}                   /     \                   天地无极   ${AnsiColor.BRIGHT_YELLOW}                   /     \
${AnsiColor.BRIGHT_RED}   |            | (       ) |            |      ${AnsiColor.BRIGHT_YELLOW}乾坤戒法   |            | (       ) |            |
${AnsiColor.BRIGHT_RED}  /^\  |       /^\ \     / /^\       |  /^\  元阳入体   ${AnsiColor.BRIGHT_YELLOW}  /^\  |       /^\ \     / /^\       |  /^\
${AnsiColor.BRIGHT_RED}  |O| /^\     (   )|-----|(   )     /^\ |O|     ${AnsiColor.BRIGHT_YELLOW}五毒不侵  |O| /^\     (   )|-----|(   )     /^\ |O|
${AnsiColor.BRIGHT_RED}  |_| |-| |^-^|---||-----||---|^-^| |-| |_|  九阳之体   ${AnsiColor.BRIGHT_YELLOW}  |_| |-| |^-^|---||-----||---|^-^| |-| |_|
${AnsiColor.BRIGHT_RED}  |O| |O| |/^\|/^\||  |  ||/^\|/^\| |O| |O|     ${AnsiColor.BRIGHT_YELLOW}化缘神功  |O| |O| |/^\|/^\||  |  ||/^\|/^\| |O| |O|
${AnsiColor.BRIGHT_RED}  |-| |-| ||_|||_||| /^\ |||_|||_|| |-| |-|  邪魔退散   ${AnsiColor.BRIGHT_YELLOW}  |-| |-| ||_|||_||| /^\ |||_|||_|| |-| |-|
${AnsiColor.BRIGHT_RED}  |O| |O| |/^\|/^\||(   )||/^\|/^\| |O| |O|     ${AnsiColor.BRIGHT_YELLOW}永不宕机  |O| |O| |/^\|/^\||(   )||/^\|/^\| |O| |O|
${AnsiColor.BRIGHT_RED}  |-| |-| ||_|||_||||   ||||_|||_|| |-| |-|  永无八哥   ${AnsiColor.BRIGHT_YELLOW}  |-| |-| ||_|||_||||   ||||_|||_|| |-| |-|
${AnsiColor.BRIGHT_CYAN}
```
![image.png](https://img.hacpai.com/file/2019/08/image-f16722bb.png)

```
${AnsiColor.BRIGHT_YELLOW}
                       d*##$.
 zP"""""$e.           $"    $o
4$       '$          $"      $
'$        '$        J$       $F
 'b        $k       $>       $
  $K        $r     J$       d$
  '$         $     $"       $~
   '$        "$   '$E       $
    $         $L   $"      $F ...
     $.       4B   $      $$$*"""*b
     '$        $.  $$     $$      $F
      "$       RS  $F     $"      $
       $k      ?$ u*     dF      .$
       ^$.      $$"     z$      u$$$$e
        #Sb             $E.dW@e$"    ?$
         #$           .o$$# d$$$$c    ?F
          $      .d$$#" . zo$>   #$r .uF
          $L .u$*"      $&$$$k   .$$d$$F
           $$"            ""^"$$$P"$P9$
          JP              .o$$$$u:$P $$
          $          ..ue$"      ""  $"
         d$          $F              $
         $$      ...udE             4B
          #$     """` $r            @$
           ^$L        '$            $F
             RN        4N           $
              *Sb                  d$
               $$k                 $F
                $$b                $F
                 $""               $F
                 '$                $
                  $L               $
                  '$               $
                   $               $
                   

```




