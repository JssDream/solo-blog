title: Spring Boot2.0配置Jackson日期格式输出
date: '2019-08-23 12:03:40'
updated: '2019-08-23 14:25:08'
tags: [SpringBoot, Json, 日期输出, 随记]
permalink: /articles/2019/08/23/1566533019629.html
---
![](https://img.hacpai.com/bing/20190306.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

## 起因
	
> 今天写项目的时候发现实体对象中的字段有`Date`类型的，这样进行直接输出来的格式不是前端需要，每次都需要使用工具类进行转化，感觉很麻烦！而且在前端进行传递对应字段是`Date`类型的值得时候，也不好出来(PS:自己前端比较渣)，在测试接口的时候，使用postman发现其也是没办法传`Date`类型的参数，当然也是有传递时间戳的方式，但是测试而已没必要那么麻烦，所以就在网上查阅资料，找到了对应的`Jackson`相关配置！

**SpringBoot JSON工具包默认是Jackson，只需要引入spring-boot-starter-web依赖包，自动引入相应依赖包**

## 以往的方法

> 之前我们都是直接进行格式化日期，然后输出才是前端需要的(图1,详情输出\图2新增参数报错)

![image.png](https://img.hacpai.com/file/2019/08/image-e88be2f5.png)

![image.png](https://img.hacpai.com/file/2019/08/image-1242c928.png)

## Jackson时间格式介绍

>jackson支持的时间格式:

	"yyyy-MM-dd'T'HH:mm:ss.SSSZ"  
	"yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"  
	"EEE, dd MMM yyyy HH:mm:ss zzz"  
	"yyyy-MM-dd" 

>类型倒是挺丰富的，但就是没有常用的yyyy-MM-dd HH:mm:ss格式

## 解决方法

* 1.可以直接在字段上加上注解：@JsonFormat( pattern="yyyy-MM-dd HH:mm:ss")
* 直接在**application.yml**文件中添加如下配置：
	```
	spring: 
		jackson: 
			time-zone: GMT+8 
			date-format: yyyy-MM-dd  HH:mm:ss
	```
	上面配置对应的**properties**文件版本：

	```
	#jackson相关配置 
	spring.jackson.date-format = yyyy-MM-dd HH:mm:ss 
	#时区必须要设置 
	spring.jackson.time-zone= GMT+8 
	
	```
## 效果

> 不需要使用工具类转化；

![image.png](https://img.hacpai.com/file/2019/08/image-814340da.png)

![image.png](https://img.hacpai.com/file/2019/08/image-bc4aadfd.png)

