title: 分享—随机二次元图片API
date: '2020-05-26 14:43:38'
updated: '2020-05-26 14:49:44'
tags: [API, 分享, 二次元]
permalink: /articles/2020/05/26/1590475418750.html
---
![9ad78a99d3fe.jpeg](https://b3logfile.com/file/2020/05/9ad78a99d3fe-0d4c1f4c.jpeg)

## 二次元 API

### 地址

https://moebi.org/pic.php

### 参数

JSON

![image.png](https://b3logfile.com/file/2020/05/image-8cb307fb.png)

