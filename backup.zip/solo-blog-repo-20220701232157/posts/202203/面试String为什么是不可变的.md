title: 面试：String 为什么是不可变的？
date: '2022-03-21 14:32:55'
updated: '2022-03-21 14:35:30'
tags: [Java, 面试, String]
permalink: /articles/2022/03/21/1647844375128.html
---
![3.png](https://b3logfile.com/file/2022/03/3-9c469d7a.png)

> 分享一道群友去阿里云面试遇到的 Java 基础面试真题：“`String`、`StringBuffer`、`StringBuilder` 的区别？`String` 为什么是不可变的?”。

网站很多文章都把 `String` 不可变的原因讲错了，建议你重点关注一下。另外，本文还提到了 ：“Java 9 为何要将 String  的底层实现由 `char[]` 改成了 `byte[]` ?”

下面是正文。

**可变性**

简单的来说：`String` 类中使用 `final` 关键字修饰字符数组来保存字符串，所以`String` 对象是不可变的。

```
public final class String implements java.io.Serializable, Comparable<String>, CharSequence {
    private final char value[];
 //...
}
```

> 🐛 修正 ：我们知道被 `final` 关键字修饰的类不能被继承，修饰的方法不能被重写，修饰的变量是基本数据类型则值不能改变，修饰的变量是引用类型则不能再指向其他对象。因此，`final` 关键字修饰的数组保存字符串并不是 `String` 不可变的根本原因，因为这个数组保存的字符串是可变的（`final` 修饰引用类型变量的情况）。
> 
> `String` 真正不可变有下面几点原因：
> 
> 1. 保存字符串的数组被 `final` 修饰且为私有的，并且`String` 类没有提供/暴露修改这个字符串的方法。
> 2. `String` 类被 `final` 修饰导致其不能被继承，进而避免了子类破坏 `String` 不可变。
> 
> 相关阅读：如何理解 String 类型值的不可变？- 知乎提问^[1]^
> 
> 补充（来自issue 675^[2]^ ）：在 Java 9 之后，`String` 、`StringBuilder` 与 `StringBuffer` 的实现改用 `byte` 数组存储字符串。
> 
> **Java 9 为何要将 `String` 的底层实现由 `char[]` 改成了 `byte[]` ?**
> 
> 新版的 String 其实支持两个编码方案：Latin-1 和 UTF-16。如果字符串中包含的汉字没有超过 Latin-1 可表示范围内的字符，那就会使用 Latin-1 作为编码方案。Latin-1 编码方案下，`byte` 占一个字节(8 位)，`char` 占用 2 个字节（16），`byte` 相较 `char` 节省一半的内存空间。
> 
> 如果字符串中包含的汉字超过 Latin-1 可表示范围内的字符，`byte` 和 `char` 所占用的空间是一样的。
> 
> 这是官方的介绍：https://openjdk.java.net/jeps/254 。

`StringBuilder` 与 `StringBuffer` 都继承自 `AbstractStringBuilder` 类，在 `AbstractStringBuilder` 中也是使用字符数组保存字符串，不过没有使用 `final` 和 `private` 关键字修饰，最关键的是这个 `AbstractStringBuilder` 类还提供了很多修改字符串的方法比如 `append` 方法。

```
abstract class AbstractStringBuilder implements Appendable, CharSequence {
    char[] value;
    public AbstractStringBuilder append(String str) {
        if (str == null)
            return appendNull();
        int len = str.length();
        ensureCapacityInternal(count + len);
        str.getChars(0, len, value, count);
        count += len;
        return this;
    }
   //...
}
```

**线程安全性**

`String` 中的对象是不可变的，也就可以理解为常量，线程安全。`AbstractStringBuilder` 是 `StringBuilder` 与 `StringBuffer` 的公共父类，定义了一些字符串的基本操作，如 `expandCapacity`、`append`、`insert`、`indexOf` 等公共方法。`StringBuffer` 对方法加了同步锁或者对调用的方法加了同步锁，所以是线程安全的。`StringBuilder` 并没有对方法进行加同步锁，所以是非线程安全的。

**性能**

每次对 `String` 类型进行改变的时候，都会生成一个新的 `String` 对象，然后将指针指向新的 `String` 对象。`StringBuffer` 每次都会对 `StringBuffer` 对象本身进行操作，而不是生成新的对象并改变对象引用。相同情况下使用 `StringBuilder` 相比使用 `StringBuffer` 仅能获得 10%~15% 左右的性能提升，但却要冒多线程不安全的风险。

**对于三者使用的总结：**

1. 操作少量的数据: 适用 `String`
2. 单线程操作字符串缓冲区下操作大量数据: 适用 `StringBuilder`
3. 多线程操作字符串缓冲区下操作大量数据: 适用 `StringBuffer`

### 参考资料

[1]如何理解 String 类型值的不可变？- 知乎提问: *https://www.zhihu.com/question/20618891/answer/114125846*

[2]issue 675: *https://github.com/Snailclimb/JavaGuide/issues/675*

> 原文地址：[阿里云二面： String 为什么不可变？](https://mp.weixin.qq.com/s/MwaZqbXw9W0S30mXljQhuA)

