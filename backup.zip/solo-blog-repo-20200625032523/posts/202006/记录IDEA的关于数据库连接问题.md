title: 记录IDEA的关于数据库连接问题
date: '2020-06-10 20:14:25'
updated: '2020-06-10 20:14:25'
tags: [随记, IDEA]
permalink: /articles/2020/06/10/1591791265043.html
---
![wallhaven6k3oox.jpg](https://b3logfile.com/file/2020/06/wallhaven6k3oox-383d735c.jpg)

## 序

	今天更新了IDEA，更新到2020.1.1，发现了两个关于数据库问题。

### 1. IDEA 数据库连接，密码不保存，重复输入问题

> 明明是永远save，就是不起作用，每次重启IDEA都要输入。
![image.png](https://b3logfile.com/file/2020/06/image-8f3f9532.png)

#### 解答：

在IDEA File—>Setting—>搜索In KeePass，然后勾选即可。

![image.png](https://b3logfile.com/file/2020/06/image-d86cc7bf.png)

### 2. IDEA 数据库连接上，mapper.xml文件中sql的表名和字段，不能点击问题

#### 解答：

* 首先连接数据源
*  File->Settings->Languages&Frameworks->SQL Resolution Scopes 勾选所有数据源
	![image.png](https://b3logfile.com/file/2020/06/image-323824e3.png)
* File->Settings->Languages&Frameworks->SQL Dialects -> 全局和项目选择MySQL
	![image.png](https://b3logfile.com/file/2020/06/image-8542af4c.png)

## OK，解决！
