title: SpringBoot自定义参数解析器—HandlerMethodArgumentResolver
date: '2019-11-08 16:54:24'
updated: '2019-11-08 16:55:08'
tags: [SpringBoot, 随记]
permalink: /articles/2019/11/08/1573203264692.html
---
![t016721f6e9d938494e.jpg](https://img.hacpai.com/file/2019/11/t016721f6e9d938494e-67a1e696.jpg)

## 介绍
使用自定义参数解析器进行全局参数(用户信息UserInfo)注入，可以使用注解，也可以直接对象！

`HandlerMethodArgumentResolver`：处理函数参数的分解器，自定义需要实现这个接口(在SpringMVC中也可以使用)

![image.png](https://img.hacpai.com/file/2019/11/image-3bd68181.png)

> 接口方法
* `supportsParameter`：用于判定是否需要处理该参数分解，必须返回true才会去调用下面的方法resolveArgument。(博主之前就是这个问题)  
* `resolveArgument`：真正用于处理参数分解的方法，返回的Object就是controller方法上的形参对象

## 实现

博主使用的是`UserInfo`对象注入(注解方式自行百度)

### 自定义参数解析器，实现HandlerMethodArgumentResolver接口
```
package com.bigbigsun.assets.admin.config;

import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.jssdream.common.redis.RedisTemplateUtil;
import com.jssdream.common.util.TokenUtil;
import com.jssdream.common.util.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.MethodParameter;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.support.WebDataBinderFactory;
import org.springframework.web.context.request.NativeWebRequest;
import org.springframework.web.method.support.HandlerMethodArgumentResolver;
import org.springframework.web.method.support.ModelAndViewContainer;
import javax.servlet.http.HttpServletRequest;

/**
 * 
 * 将登陆用户可以直接注入的形式获取
 */
@Service
public class UserArgumentResolver implements HandlerMethodArgumentResolver {
    @Autowired
    RedisTemplateUtil redisService;
    @Override
    public boolean supportsParameter(MethodParameter methodParameter) {
        Class<?> clazz = methodParameter.getParameterType();
        return clazz== User.class;
	//也可以
	/*return true;
	return parameter.hasParameterAnnotation(User.class);*/
    }

    @Override
    public Object resolveArgument(MethodParameter methodParameter, ModelAndViewContainer modelAndViewContainer,
                                  NativeWebRequest nativeWebRequest, WebDataBinderFactory webDataBinderFactory) {
        HttpServletRequest request = nativeWebRequest.getNativeRequest(HttpServletRequest.class);
        //获取token
        String token = TokenUtil.getToken(request);
        User userInfo = StrUtil.isBlank(token) ? null : JSONObject.toJavaObject(JSON.parseObject(redisService.getKey(token)),User.class);
        if(userInfo == null) {
            return null;
        }
        return userInfo;
    }
}

```
### 将UserArgumentResolver加入到WebMvcConfigurerAdapter中
```
package com.jssdream.admin.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.method.support.HandlerMethodArgumentResolver;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
import java.util.List;


@Configuration
public class WebConfig extends WebMvcConfigurerAdapter {
    @Autowired
    UserArgumentResolver userArgumentResolver;

    @Override
    public void addArgumentResolvers(List<HandlerMethodArgumentResolver> argumentResolvers) {
        argumentResolvers.add(userArgumentResolver);
    }
    
}

```
### Controller中使用用户信息

```
@RequestMapping("user")
public User getUser(User user){
   
    return user;
}
```

## 最后

WebMvcConfigurerAdapter这个抽象类中的方法可以看一看，addInterceptors可以添加拦截器

```
@Override
public void addInterceptors(InterceptorRegistry registry) {
         // 拦截所有请求，进行判断
    }

```
