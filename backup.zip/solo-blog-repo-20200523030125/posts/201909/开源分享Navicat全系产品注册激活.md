title: 开源分享—Navicat全系产品注册激活
date: '2019-09-11 19:38:09'
updated: '2020-04-17 20:09:48'
tags: [福利, 分享, 开源软件]
permalink: /articles/2019/09/11/1568201889402.html
---
![](https://img.hacpai.com/bing/20180523.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 开题

关于Navicat的破解激活相信使用数据库的都会使用到，前段时间换了公司，之后又是一波安装软件，然后网上找破解教程，找半天，然后下次用的时候又没有，这就很尴尬，于是想着把教程记录下来，激活软件也记录下！！！而且这次发现了 `GitHub`上面有两款开源的激活软件，这就很nice！:huaji:

## 软件下载地址

直接在Navicat的官网进行[下载](https://www.navicat.com.cn/products)
![image.png](https://img.hacpai.com/file/2019/09/image-44bfdda1.png)
选择自己需要的产品点击【免费试用】即可下载软件！

## 开源软件地址

两种激活软件，原理应该是一样，只是操作流程不一样

* [https://github.com/DoubleLabyrinth/navicat-keygen](https://github.com/DoubleLabyrinth/navicat-keygen)
  参考地址：[教程](https://github.com/DoubleLabyrinth/navicat-keygen/blob/windows/README.zh-CN.md)
* [https://github.com/Deltafox79/Navicat_Keygen](https://github.com/Deltafox79/Navicat_Keygen)
  参考地址:[教程](https://github.com/Deltafox79/Navicat_Keygen/releases)
  ![Navicat_Keygen_Patch_v5 2_By_DFoX](https://user-images.githubusercontent.com/2518850/64677699-60666c80-d478-11e9-97e6-6b7388016aba.jpg)
  基本操作：双击软件，基本不需要改变界面
  1. 点击patch查找安装目录下面的Navicat.exe文件
  2. 直接 `4）`可以定制属于自己名称的秘钥
     ![](https://upload-images.jianshu.io/upload_images/7213631-617c0378d9059b8c.png?imageMogr2/auto-orient/strip|imageView2/2/w/1200/format/webp)
     ![](https://upload-images.jianshu.io/upload_images/7213631-c25c34ee2fe8c032.png?imageMogr2/auto-orient/strip|imageView2/2/w/1200/format/webp)
  3. 将秘钥粘贴到软件注册页面，然后点击手动激活，复制秘钥到破解软件
     ![](https://upload-images.jianshu.io/upload_images/7213631-a97ac52f1e96130a.png?imageMogr2/auto-orient/strip|imageView2/2/w/1200/format/webp)
     4 点击左下角的 `Generate`，将新生成的 `code` copy到刚刚的软件激活页面，OK了！
     ![](https://upload-images.jianshu.io/upload_images/7213631-c920756846df68df.png?imageMogr2/auto-orient/strip|imageView2/2/w/1200/format/webp)

> PS:第一种没有界面，直接在cmd中进行操作；第二中有对应的图像，一目了然

## 结束

注意杀毒软件的屏蔽！！！！

附加：[百度网盘链接](https://pan.baidu.com/s/1_q7xawvmn15BGC1oGBZhEw) 提取码: hwep

[最新破解文件](https://pan.baidu.com/s/1kikA5lJac26m3KRHl681ug) 提取码: v867
