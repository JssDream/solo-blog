title: 笔记—获取请求IP方法整理
date: '2019-12-04 14:56:59'
updated: '2019-12-05 14:32:12'
tags: [Java, 随记]
permalink: /articles/2019/12/04/1575442618755.html
---
![](https://img.hacpai.com/bing/20171111.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 


## 笔记

```
/**
     * 获取真实IP
     * <p>
     * X-Forwarded-For：Squid 服务代理 只有在通过了HTTP代理或者负载均衡服务器时才会添加该项，
     * 格式为X-Forwarded-For:client1,proxy1,proxy2，一般情况下，第一个ip为客户端真实ip，后面的为经过的代理服务器ip
     * <p>
     * Proxy-Client-IP：apache 服务代理
     * <p>
     * WL-Proxy-Client-IP：weblogic 服务代理
     * <p>
     * HTTP_CLIENT_IP：有些代理服务器
     * <p>
     * X-Real-IP：nginx服务代理
     *
     * @param request 请求体
     * @return 真实IP
     */
    public static String getRealIp(HttpServletRequest request) {
        // 这个一般是Nginx反向代理设置的参数
        String ip = request.getHeader("X-Real-IP");
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("X-Forwarded-For");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("Proxy-Client-IP");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("WL-Proxy-Client-IP");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("HTTP_CLIENT_IP");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("HTTP_X_FORWARDED_FOR");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getRemoteAddr();
        }
        //根据网卡取本机配置的IP
//        if(ip.equals("127.0.0.1") || ip.equals("0:0:0:0:0:0:0:1")){
//            InetAddress inet=null;
//            try {
//                inet = InetAddress.getLocalHost();
//            } catch (UnknownHostException e) {
//                e.printStackTrace();
//            }
//            ip= inet.getHostAddress();
//        }
        // 处理多IP的情况（只取第一个IP）
        if (ip != null && ip.contains(",")) {
            String[] ipArray = ip.split(",");
            ip = ipArray[0];
        }
        ip = ip.equals("0:0:0:0:0:0:0:1") ? "127.0.0.1" : ip;
        return ip;
    }

```

### 说明
> 获取用户真实IP地址，为什么不直接使用request.getRemoteAddr()的原因是有可能用户使用了代理方式避免真实IP地址，如果使用了代理就可能出现多级反向代理，那X-Forwarded-For的值并不止一个，而是一串IP值，至于哪个才是真正的用户端的真实IP? 答案是取X-Forwarded-For中第一个非unknown的有效IP字符串，而且可能获取的是代理服务器的IP

## 结束
