title: Github+jsDelivr为脚本/图片等静态文件加速的全球CDN
date: '2020-04-01 18:13:31'
updated: '2020-04-01 18:37:37'
tags: [GitHub, 分享, 随记]
permalink: /articles/2020/04/01/1585736011733.html
---
![2142231584798143d453.jpg](https://img.hacpai.com/file/2020/04/2142231584798143d453-fb0fce4f.jpg)

## 前言

> 众所周知，Github是目前最大的项目的托管平台，而且免费套餐还支持私有仓库了！但是呐，国内访问比较慢！！

今天给介绍一种加速访问方式 `jsDelivr CDN`

jsDelivr提供npm，GitHub，WordPress等项目的镜像，全球加速访问！

针对Github提供免费的CDN加速，在国内使用的是网宿的CDN加速！访问速度一点儿都不慢！

## 使用限制

* 目前Github仓库容量是没有上限的！不过官方推荐在1G以内！
* 仓库单个文件50M会收到警告，大于100M会被拒绝！
* jsDelivr仅能针对50M以下的文件CDN加速！

但是利用它读取静态文件处处有余，如JS、CSS、图片、文件等！

## 方式

> 这里以图床方式

* 创建一个 GitHub 仓库作为图床仓库，上传提交图片到仓库中
* 在要使用 GitHub 图床图片的地方将链接换为 https://cdn.jsdelivr.net/gh/你的用户名/你的仓库名@发布的版本号/文件路径

**例如**：https://cdn.jsdelivr.net/gh/JssDream/image-hosting/img/002_2.jpg

简单吧！！！:huaji:

 
> 转自：[如有乐享](https://51.ruyo.net/15149.html)
